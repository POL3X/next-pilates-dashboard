'use client';
import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

import { Status, Task, useTaskStore } from '@/lib/store';
import { hasDraggableData } from '@/lib/utils';
import {
  Announcements,
  DndContext,
  DragOverlay,
  MouseSensor,
  TouchSensor,
  UniqueIdentifier,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent
} from '@dnd-kit/core';
import { SortableContext, arrayMove } from '@dnd-kit/sortable';
import type { Column } from './board-column';
import { BoardColumn } from './board-column';
import NewSectionDialog from './new-section-dialog';
import { TaskCard } from './task-card';
import { ScrollArea } from '../ui/scroll-area';
// import { coordinateGetter } from "./multipleContainersKeyboardPreset";

// Ahora tenemos columnas padre que contienen columnas hijo
const defaultParentCols = [
  {
    id: 'PARENT_1',
    title: 'Parent Column 1',
    childCols: [
      { id: 'CHILD_1', title: 'Child Column 1' },
      { id: 'CHILD_2', title: 'Child Column 2' }
    ]
  },
  {
    id: 'PARENT_2',
    title: 'Parent Column 2',
    childCols: [
      { id: 'CHILD_3', title: 'Child Column 3' },
      { id: 'CHILD_4', title: 'Child Column 4' }
    ]
  }
];

// El tipo ColumnId para identificar las columnas hijo
export type ColumnId = (typeof defaultParentCols)[number]['childCols'][number]['id'];

export function KanbanBoard() {
  const [parentCols, setParentCols] = useState(defaultParentCols);
  
  const columns = useTaskStore((state) => state.parentColumns); // Mantenemos el sistema de columnas
  const setColumns = useTaskStore((state) => state.setCols); // Función para actualizar columnas
  const pickedUpTaskColumn = useRef<ColumnId | null>(null); // Para hacer seguimiento de la columna donde se levantó la tarea
  const tasks = useTaskStore((state) => state.tasks); // Tareas desde el store
  const setTasks = useTaskStore((state) => state.setTasks);
  const [activeColumn, setActiveColumn] = useState<Column | null>(null);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [isMounted, setIsMounted] = useState<Boolean>(false);

  const sensors = useSensors(
    useSensor(MouseSensor),
    useSensor(TouchSensor)
  );

  useEffect(() => {
    setIsMounted(true);
  }, [isMounted]);

  useEffect(() => {
    useTaskStore.persist.rehydrate();
  }, []);

  if (!isMounted) return null;

  // Obtener información de la tarea que está siendo arrastrada
  function getDraggingTaskData(taskId: UniqueIdentifier, columnId: ColumnId) {
    const tasksInColumn = tasks.filter((task) => task.status === columnId);
    const taskPosition = tasksInColumn.findIndex((task) => task.id === taskId);
    const column = columns.find((col: { id: string; }) => col.id === columnId);
    return {
      tasksInColumn,
      taskPosition,
      column
    };
  }

  // Anuncios para accesibilidad durante drag-and-drop
  const announcements: Announcements = {
    onDragStart({ active }) {
      if (!hasDraggableData(active)) return;
      if (active.data.current?.type === 'Column') {
        const startColumnIdx = columns.findIndex((col: { id: UniqueIdentifier; }) => col.id === active.id);
        const startColumn = columns[startColumnIdx];
        return `Picked up Column ${startColumn?.title} at position: ${
          startColumnIdx + 1
        } of ${columns.length}`;
      } else if (active.data.current?.type === 'Task') {
        pickedUpTaskColumn.current = active.data.current.task.status;
        const { tasksInColumn, taskPosition, column } = getDraggingTaskData(
          active.id,
          pickedUpTaskColumn.current
        );
        return `Picked up Task ${active.data.current.task.title} at position: ${
          taskPosition + 1
        } of ${tasksInColumn.length} in column ${column?.title}`;
      }
    },
    onDragOver({ active, over }) {
      if (!hasDraggableData(active) || !hasDraggableData(over)) return;

      if (
        active.data.current?.type === 'Column' &&
        over.data.current?.type === 'Column'
      ) {
        const overColumnIdx = columns.findIndex((col: { id: UniqueIdentifier; }) => col.id === over.id);
        return `Column ${active.data.current.column.title} was moved over ${
          over.data.current.column.title
        } at position ${overColumnIdx + 1} of ${columns.length}`;
      } else if (
        active.data.current?.type === 'Task' &&
        over.data.current?.type === 'Task'
      ) {
        const { tasksInColumn, taskPosition, column } = getDraggingTaskData(
          over.id,
          over.data.current.task.status
        );
        if (over.data.current.task.status !== pickedUpTaskColumn.current) {
          return `Task ${
            active.data.current.task.title
          } was moved over column ${column?.title} in position ${
            taskPosition + 1
          } of ${tasksInColumn.length}`;
        }
        return `Task was moved over position ${taskPosition + 1} of ${
          tasksInColumn.length
        } in column ${column?.title}`;
      }
    },
    onDragEnd({ active, over }) {
      if (!hasDraggableData(active) || !hasDraggableData(over)) {
        pickedUpTaskColumn.current = null;
        return;
      }
      if (
        active.data.current?.type === 'Column' &&
        over.data.current?.type === 'Column'
      ) {
        const overColumnPosition = columns.findIndex((col: { id: UniqueIdentifier; }) => col.id === over.id);
        return `Column ${
          active.data.current.column.title
        } was dropped into position ${overColumnPosition + 1} of ${
          columns.length
        }`;
      } else if (
        active.data.current?.type === 'Task' &&
        over.data.current?.type === 'Task'
      ) {
        const { tasksInColumn, taskPosition, column } = getDraggingTaskData(
          over.id,
          over.data.current.task.status
        );
        if (over.data.current.task.status !== pickedUpTaskColumn.current) {
          return `Task was dropped into column ${column?.title} in position ${
            taskPosition + 1
          } of ${tasksInColumn.length}`;
        }
        return `Task was dropped into position ${taskPosition + 1} of ${
          tasksInColumn.length
        } in column ${column?.title}`;
      }
      pickedUpTaskColumn.current = null;
    },
    onDragCancel({ active }) {
      pickedUpTaskColumn.current = null;
      if (!hasDraggableData(active)) return;
      return `Dragging ${active.data.current?.type} cancelled.`;
    }
  };

  // Render de columnas padre e hijo con tareas
  return (
    <DndContext
      accessibility={{
        announcements
      }}
      sensors={sensors}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragOver={onDragOver}
    >
      <div style={{ display: 'flex', gap: '16px', overflowX: 'auto' }}>
        {parentCols.map((parent) => (
          <div key={parent.id} style={{ border: '1px solid #ccc', padding: '8px' }}>
            <h2>{parent.title}</h2>
            <div style={{ display: 'flex', gap: '8px' }}>
              {parent.childCols.map((child) => (
                <BoardColumn
                  key={child.id}
                  column={child}
                  parentId={parent.id}
                  tasks={tasks.filter((task) => task.status === child.id)} // Filtrar tareas por columna hija
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Overlay durante el drag */}
      {'document' in window &&
        createPortal(
          <DragOverlay>
            {activeColumn && (
              <BoardColumn
                isOverlay
                column={activeColumn}
                parentId={activeColumn.id.toLocaleString()}
                tasks={tasks.filter((task) => task.status === activeColumn.id)}
              />
            )}
            {activeTask && <TaskCard task={activeTask} isOverlay />}
          </DragOverlay>,
          document.body
        )}
    </DndContext>
  );

  function onDragStart(event: DragStartEvent) {
    if (!hasDraggableData(event.active)) return;
    const data = event.active.data.current;
    if (data?.type === 'Column') {
      setActiveColumn(data.column);
      return;
    }

    if (data?.type === 'Task') {
      setActiveTask(data.task);
      return;
    }
  }

  function onDragEnd(event: DragEndEvent) {
    setActiveColumn(null);
    setActiveTask(null);

    const { active, over } = event;
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (!hasDraggableData(active)) return;

    const activeData = active.data.current;

    if (activeId === overId) return;

    const isActiveAColumn = activeData?.type === 'Column';
    if (!isActiveAColumn) return;

    const activeColumnIndex = columns.findIndex((col: { id: UniqueIdentifier; }) => col.id === activeId);
    const overColumnIndex = columns.findIndex((col: { id: UniqueIdentifier; }) => col.id === overId);

    setColumns(arrayMove(columns, activeColumnIndex, overColumnIndex));
  }

  function onDragOver(event: DragOverEvent) {
    const { active, over } = event;
    if (!over) return;
  
    const activeId = active.id;
    const overId = over.id;
  
    if (activeId === overId) return;
  
    if (!hasDraggableData(active) || !hasDraggableData(over)) return;
  
    const activeData = active.data.current;
    const overData = over.data.current;
  
    const isActiveATask = activeData?.type === 'Task';
    const isOverAColumn = overData?.type === 'Column';
  
    if (isActiveATask && isOverAColumn) {
      const activeIndex = tasks.findIndex((t) => t.id === activeId);
      const activeTask = tasks[activeIndex];
  
      // Convertimos el overId a un valor del tipo Status
      const newStatus = overId as Status;
  
      // Validamos que el newStatus es un valor válido dentro del enum 'Status'
      if (activeTask && ['TODO', 'IN_PROGRESS', 'DONE'].includes(newStatus)) {
        activeTask.status = newStatus;
        setTasks(arrayMove(tasks, activeIndex, activeIndex));
      }
    }
  }
}
